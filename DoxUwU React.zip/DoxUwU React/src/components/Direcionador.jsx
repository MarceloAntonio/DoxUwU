export { default as Home } from "./Home"
export { default as Sobre } from "./Sobre"
export { default as Registro } from "./Doxing"
